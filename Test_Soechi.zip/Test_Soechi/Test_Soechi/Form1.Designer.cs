﻿
namespace Test_Soechi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.txt_QytKecil = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txt_Qyt = new System.Windows.Forms.TextBox();
            this.txt_Total = new System.Windows.Forms.TextBox();
            this.txt_UnitPrice = new System.Windows.Forms.TextBox();
            this.txt_DiscAmt = new System.Windows.Forms.TextBox();
            this.txt_Disc = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.cmb_UOM = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(343, 203);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Table Satuan/UOM";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Test_Soechi.Properties.Resources.Satuan;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(33, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(266, 142);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Item Desc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "UOM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 327);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Qty";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(65, 378);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Unit Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 431);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Discount";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(65, 482);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "Discount Amt";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(70, 536);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Total";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(548, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Rate";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(548, 321);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "Qyt Kecil";
            // 
            // txtRate
            // 
            this.txtRate.Enabled = false;
            this.txtRate.Location = new System.Drawing.Point(683, 276);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(181, 31);
            this.txtRate.TabIndex = 10;
            // 
            // txt_QytKecil
            // 
            this.txt_QytKecil.BackColor = System.Drawing.SystemColors.GrayText;
            this.txt_QytKecil.Enabled = false;
            this.txt_QytKecil.Location = new System.Drawing.Point(683, 318);
            this.txt_QytKecil.Name = "txt_QytKecil";
            this.txt_QytKecil.Size = new System.Drawing.Size(181, 31);
            this.txt_QytKecil.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(226, 234);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(266, 31);
            this.textBox3.TabIndex = 12;
            // 
            // txt_Qyt
            // 
            this.txt_Qyt.Location = new System.Drawing.Point(226, 321);
            this.txt_Qyt.Name = "txt_Qyt";
            this.txt_Qyt.Size = new System.Drawing.Size(266, 31);
            this.txt_Qyt.TabIndex = 14;
            // 
            // txt_Total
            // 
            this.txt_Total.BackColor = System.Drawing.SystemColors.GrayText;
            this.txt_Total.Enabled = false;
            this.txt_Total.Location = new System.Drawing.Point(226, 530);
            this.txt_Total.Name = "txt_Total";
            this.txt_Total.Size = new System.Drawing.Size(266, 31);
            this.txt_Total.TabIndex = 15;
            // 
            // txt_UnitPrice
            // 
            this.txt_UnitPrice.Location = new System.Drawing.Point(226, 372);
            this.txt_UnitPrice.Name = "txt_UnitPrice";
            this.txt_UnitPrice.Size = new System.Drawing.Size(266, 31);
            this.txt_UnitPrice.TabIndex = 16;
            // 
            // txt_DiscAmt
            // 
            this.txt_DiscAmt.BackColor = System.Drawing.SystemColors.GrayText;
            this.txt_DiscAmt.Enabled = false;
            this.txt_DiscAmt.Location = new System.Drawing.Point(226, 476);
            this.txt_DiscAmt.Name = "txt_DiscAmt";
            this.txt_DiscAmt.Size = new System.Drawing.Size(266, 31);
            this.txt_DiscAmt.TabIndex = 17;
            // 
            // txt_Disc
            // 
            this.txt_Disc.Location = new System.Drawing.Point(226, 425);
            this.txt_Disc.Name = "txt_Disc";
            this.txt_Disc.Size = new System.Drawing.Size(266, 31);
            this.txt_Disc.TabIndex = 18;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(570, 425);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(290, 62);
            this.button2.TabIndex = 19;
            this.button2.Text = "Klik Untuk Hitung";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmb_UOM
            // 
            this.cmb_UOM.FormattingEnabled = true;
            this.cmb_UOM.Items.AddRange(new object[] {
            "PCS",
            "LUSIN",
            "BOX"});
            this.cmb_UOM.Location = new System.Drawing.Point(226, 279);
            this.cmb_UOM.Name = "cmb_UOM";
            this.cmb_UOM.Size = new System.Drawing.Size(266, 33);
            this.cmb_UOM.TabIndex = 20;
            this.cmb_UOM.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(935, 594);
            this.Controls.Add(this.cmb_UOM);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txt_Disc);
            this.Controls.Add(this.txt_DiscAmt);
            this.Controls.Add(this.txt_UnitPrice);
            this.Controls.Add(this.txt_Total);
            this.Controls.Add(this.txt_Qyt);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txt_QytKecil);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.TextBox txt_QytKecil;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txt_Qyt;
        private System.Windows.Forms.TextBox txt_Total;
        private System.Windows.Forms.TextBox txt_UnitPrice;
        private System.Windows.Forms.TextBox txt_DiscAmt;
        private System.Windows.Forms.TextBox txt_Disc;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmb_UOM;
    }
}

