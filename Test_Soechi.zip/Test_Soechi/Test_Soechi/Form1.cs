﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Soechi
{
    public partial class Form1 : Form
    {
        int pcs = 1;
        int lusin = 12;
        int box = 24;
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if(cmb_UOM.Text == "LUSIN")
            //{
            //    txtRate.Text = "12";
            //}

            int QytKecil = Convert.ToInt32(txt_Qyt.Text) * Convert.ToInt32(txtRate.Text);
            txt_QytKecil.Text = Convert.ToString(QytKecil);


            int cekPersen = txt_Disc.Text.IndexOf("%");
            int cekSimbolPlus = txt_Disc.Text.IndexOf("+");
            int temp = 0;
            int disAmt = 0;


            if (cekPersen == -1 && cekSimbolPlus == -1)
            {
                disAmt = Convert.ToInt32(txt_Disc.Text);
                txt_DiscAmt.Text = Convert.ToString(disAmt);
            }
            else if (cekPersen >= 0 && cekSimbolPlus == -1)
            {
                 temp = Convert.ToInt32(txt_Qyt.Text) * Convert.ToInt32(txt_UnitPrice.Text);

                decimal dis = Convert.ToDecimal(txt_Disc.Text.Remove(cekPersen)) / 100;

                //int hasil_dis = Convert.ToInt32(dis);
                disAmt =  Convert.ToInt32(temp*dis);

                txt_DiscAmt.Text = Convert.ToString(disAmt);



            }
            else
            {
                int discount = 0;
                //int temp = Convert.ToInt32(txt_Qyt.Text) * Convert.ToInt32(txt_UnitPrice.Text);
                string s = txt_Disc.Text;
                string[] subs = s.Split('+');
                temp = Convert.ToInt32(txt_Qyt.Text) * Convert.ToInt32(txt_UnitPrice.Text);
                foreach (var sub in subs)
                {
                    cekSimbolPlus = sub.IndexOf("+");
                    cekPersen = sub.IndexOf("%");
                    if (cekPersen == -1 && cekSimbolPlus == -1)
                    {
                        disAmt = Convert.ToInt32(sub);
                        txt_DiscAmt.Text = Convert.ToString(disAmt);
                    }
                    else if (cekPersen >= 0 && cekSimbolPlus == -1)
                    {
                        decimal dis = Convert.ToDecimal(sub.Remove(cekPersen)) / 100;

                        disAmt = Convert.ToInt32(temp * dis);

                        txt_DiscAmt.Text = Convert.ToString(disAmt);

                    }
                    temp -= disAmt;
                    discount += Convert.ToInt32(disAmt);
                   
                }

                disAmt = Convert.ToInt32( discount);
                txt_DiscAmt.Text = Convert.ToString(disAmt);
            }
            temp = Convert.ToInt32(txt_Qyt.Text) * Convert.ToInt32(txt_UnitPrice.Text);

            // total
            int total = temp - disAmt;
            txt_Total.Text = Convert.ToString(total);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_UOM.Text == "LUSIN")
            {
                txtRate.Text = "12";
            }else if(cmb_UOM.Text == "BOX")
            {
                txtRate.Text = "24";
            }
            else
            {
                txtRate.Text = "1";
            }
        }
    }
}
